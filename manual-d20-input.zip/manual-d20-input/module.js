{
  "id": "manual-d20-input",
  "title": "Manual D20 Input (5e)",
  "description": "Allows manual entry of d20 results (normal, advantage, disadvantage) for D&D5e, with optional auto-roll.",
  "version": "1.0.0",
  "authors": [
    {
      "name": "Mark + Copilot",
      "url": "",
      "discord": ""
    }
  ],
  "compatibility": {
    "minimum": "11",
    "verified": "12"
  },
  "esmodules": [
    "scripts/main.js"
  ],
  "relationships": {
    "requires": [
      {
        "id": "lib-wrapper",
        "type": "module",
        "compatibility": {
          "minimum": "1.12.0"
        }
      }
    ]
  },
  "flags": {
    "allowBugReporter": false
  },
  "scripts": [],
  "styles": [],
  "packs": [],
  "languages": [],
  "url": "",
  "manifest": "",
  "download": ""
}